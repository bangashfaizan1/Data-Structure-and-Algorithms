#include "MinQueue.h"
#include <iostream>

using namespace std;

int main() {
    MinQueue Q1;
    
    cout << "Adding values from 10 - 19 into Queue one" << endl;
    cout << endl;
    
    for(int i = 10; i < 20; i++)
    {
        Q1.enqueue(i);
    }
    
    
    cout << "Elements of Queue one: " << Q1 << endl;
    cout << endl;

    cout << "Enqueueing the value '97'" << endl;
    cout << endl;
    
    Q1.enqueue(97);
    
    cout << "Elements of Queue one: " << Q1 << endl;
    cout << endl;
    
    cout << "Enqueueing the value '-1'" << endl;
    cout << endl;

    Q1.enqueue(-1);

    cout << "Elements of Queue one: " << Q1 << endl;
    cout << endl;
    
    int min = Q1.min();
    
    cout << "Min is: " << min << endl;
    cout << endl;
    
    cout << "Size is: " << Q1.size() << endl;
    cout << endl;
    
    cout << "Dequeueing the first element and returning" << endl;
    cout << endl;
    
    int first = Q1.dequeue();
    cout << "First element is: " << first << endl;
    cout << endl;
    
    cout << "Elements of Queue one: " << Q1 << endl;
    cout << endl;
    bool check = Q1.isEmpty();
    if (check == 0)
        cout << "Is the queue empty:  NO" << endl;
    else
        cout << "Is the queue empty: YES" << endl;
    
    
    
    
}