#include "MinQueue.h"


int MinQueue::min(){
	int currentmin = 0;
	if(dll.isEmpty()){
		throw runtime_error("This queue is empty");
	}
	else
	{
		currentmin = dll.getFirst()->obj;
		DListNode* current = dll.getFirst();
				
		while(current != dll.getAfterLast())
		{
			if(current->obj < currentmin ){
				currentmin = current->obj;
			}
			current = current->next;
		}
	
	}

return currentmin;
}

ostream& operator<<(ostream& out, MinQueue queue){
	if(queue.isEmpty()){
		return out << "Queue is empty";
	}
	else 
	{
		DListNode* current = queue.dll.getFirst();
		while(current != queue.dll.getAfterLast())
		{
			out << current->obj << " ";
			current = current->next;
		}
	}
	return out;
}

