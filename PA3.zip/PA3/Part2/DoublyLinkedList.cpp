#include "DoublyLinkedList.h"
#include <stdexcept>

// extend range_error from <stdexcept>
struct EmptyDLinkedListException : std::range_error {
  explicit EmptyDLinkedListException(char const* msg=NULL): range_error(msg) {}
};


// copy constructor
DoublyLinkedList::DoublyLinkedList(const DoublyLinkedList& dll)
{
  // Initialize the list
  header.next = &trailer; trailer.prev = &header;
  
  DListNode *oldNode = dll.getFirst(); 
  while(oldNode != dll.getAfterLast())
  { 
	  int newObj = oldNode->obj;
	  this->insertLast(newObj);
	  oldNode = oldNode->next;
  }
  
}

// destructor
DoublyLinkedList::~DoublyLinkedList()
{
	DListNode *prev_node, *node = header.next;
	while(node != &trailer)
	{
		prev_node = node;
		node = node->next;
		delete prev_node;
	}
	header.next = &trailer;
	trailer.prev = &header;

}

// assignment operator
DoublyLinkedList& DoublyLinkedList::operator=(const DoublyLinkedList& dll)
{
  // Delete the whole list
  if(!isEmpty())
  { 
	  DListNode *current = header.next;
	  DListNode *oldNode = header.next;
	  while(current != &trailer)
	  {
		  oldNode = current;
		  current = current->next;
		  delete oldNode;
	  }
	  header.next = &trailer;
	  trailer.prev = &header;
  }
  
  DListNode *oldNode = dll.getFirst(); 
  while(oldNode != dll.getAfterLast())
  { 
	  int newObj = oldNode->obj;
	  this->insertLast(newObj);
	  oldNode = oldNode->next;
  }
  
  return *this;
}

// return the first object
int DoublyLinkedList::first() const
{ 
	if(isEmpty())
	{
		throw EmptyDLinkedListException("Empty Doubly Linked List"); 
	}
	
	return header.next->obj;
	
}

// return the last object
int DoublyLinkedList::last() const
{
	if(isEmpty())
	{
		throw EmptyDLinkedListException("Empty Doubly Linked List");
	}
	
	return trailer.prev->obj;
	
}

// insert the new object as the first one
void DoublyLinkedList::insertFirst(int newobj)
{ 
	DListNode *anotherNode = new DListNode(newobj, &header, header.next);
	header.next->prev = anotherNode;
	header.next = anotherNode;
}
// remove the first object from the list
int DoublyLinkedList::removeFirst()
{ 
	if(isEmpty()){
		throw EmptyDLinkedListException("Empty Doubly Linked List");
	}
	else{
		DListNode *node = header.next;
		node->next->prev = &header;
		header.next = node->next;
		int obj = node->obj;
		delete node;
		return obj;
	}
}

// insert the new object as the last one
void DoublyLinkedList::insertLast(int newobj)
{
	DListNode *anotherNode = new DListNode(newobj, trailer.prev, &trailer);
	trailer.prev->next = anotherNode;
	trailer.prev = anotherNode;
}

// remove the last object from the list
int DoublyLinkedList::removeLast()
{
	if(isEmpty())
	{
		throw EmptyDLinkedListException("Empty Doubly Linked List");
	}
	else{
		DListNode *node = trailer.prev;
		node->prev->next = &trailer;
		trailer.prev = node->prev;
		int obj = node->obj;
		delete node;
		return obj;
	}
}

// insert the new object after the node p
void DoublyLinkedList::insertAfter(DListNode &p, int newobj)
{
	DListNode *current = header.next;
	while(current != &p)
	{
		current = current->next;
	}
	
	DListNode *anotherNode = new DListNode(newobj, current, current->next);
	current->next->prev = anotherNode; 
	current->next = anotherNode; 
}

// insert the new object before the node p
void DoublyLinkedList::insertBefore(DListNode &p, int newobj)
{
	DListNode *current = header.next;
	while(current != &p)
	{
		current = current->next;
	}
	
	DListNode *anotherNode = new DListNode(newobj, current->prev, current);
	current->prev->next = anotherNode; 
	current->prev = anotherNode; 
}
// remove the node after the node p
int DoublyLinkedList::removeAfter(DListNode &p)
{
	DListNode *current = header.next;
	while(current != &p)
	{
		current = current->next;
	}
	
	current = current->next; 
	current->next->prev = current->prev;
	current->prev->next = current->next;
	int obj = current->obj;
	delete current;
	return obj;
}

// remove the node before the node p
int DoublyLinkedList::removeBefore(DListNode &p)
{
	DListNode *current = header.next;
	while(current != &p)
	{
		current = current->next;
	}
	
	current = current->prev; 
	current->next->prev = current->prev;
	current->prev->next = current->next;

	int obj = current->obj;
	delete current;
	return obj;
	
}
// return the list length
int DoublyLinkedListLength(const DoublyLinkedList& dll)
{
    DListNode *current = dll.getFirst();
	int count = 0;
	while(current != dll.getAfterLast())
	{
		count++;
		current = current->next;
	}

	return count;
}


// output operator
ostream& operator<<(ostream& out, const DoublyLinkedList& dll)
{
  
  
  DListNode *current = dll.getFirst();
  int listsize = DoublyLinkedListLength(dll);
  for(int i = 0; i < listsize; i++)
  {
	  out << current->obj << " "; 
	  current = current->next; 
  }
  
  return out;
}

