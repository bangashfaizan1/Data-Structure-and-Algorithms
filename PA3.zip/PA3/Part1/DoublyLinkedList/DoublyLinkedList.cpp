#include "DoublyLinkedList.h"
#include <stdexcept>

// extend range_error from <stdexcept>
struct EmptyDLinkedListException : std::range_error {
  explicit EmptyDLinkedListException(char const* msg=NULL): range_error(msg) {}
};


//--------------------------copy constructor--------------------------
DoublyLinkedList::DoublyLinkedList(const DoublyLinkedList& dll) 
{
  // Initialize the list
  header.next = &trailer; trailer.prev = &header; // 2 operations
  
  DListNode *oldNode = dll.getFirst(); // 1 operation
  while(oldNode != dll.getAfterLast()) // goes through n times until last node
  { 
	  int newObj = oldNode->obj; // 1 operation
	  this->insertLast(newObj);//3 operation
	  oldNode = oldNode->next;//1 operation
  }
  
}

//----------------------------destructor-----------------------------
DoublyLinkedList::~DoublyLinkedList()
{
	DListNode *prev_node, *node = header.next; //2 operation
	while(node != &trailer) //n times
	{
		prev_node = node; 
		node = node->next; 
		delete prev_node;
	}
	header.next = &trailer; //1 operation
	trailer.prev = &header;// 1 operation

}

//----------------------------assignment operator------------------------
DoublyLinkedList& DoublyLinkedList::operator=(const DoublyLinkedList& dll)
{
  // only goes through this loop if list isnt empty
  if(!isEmpty())
  { 
	  DListNode *current = header.next;
	  DListNode *oldNode = header.next;
	  while(current != &trailer)
	  {
		  oldNode = current;
		  current = current->next;
		  delete oldNode;
	  }
	  header.next = &trailer;
	  trailer.prev = &header;
  }
  
  //goes through n times
  DListNode *oldNode = dll.getFirst(); // 1 operation
  while(oldNode != dll.getAfterLast()) // n times
  { 
	  int newObj = oldNode->obj;
	  this->insertLast(newObj);
	  oldNode = oldNode->next;
  }
  
  return *this;
}

//------------------------return the first object--------------------------
int DoublyLinkedList::first() const
{ 
	if(isEmpty())
	{
		throw EmptyDLinkedListException("Empty Doubly Linked List"); 
	}
	
	return header.next->obj; // 1 operation
	
}

//--------------------------return the last object-------------------------
int DoublyLinkedList::last() const
{
	if(isEmpty())
	{
		throw EmptyDLinkedListException("Empty Doubly Linked List");
	}
	
	return trailer.prev->obj; // 1 operation 
	
}

//--------------------------insert the new object as the first one-----------------
void DoublyLinkedList::insertFirst(int newobj)
{ 
	DListNode *anotherNode = new DListNode(newobj, &header, header.next); // 2 operatoin
	header.next->prev = anotherNode; // 1 operation
	header.next = anotherNode;// 1 operation
}

//------------------------remove the first object from the list-------------------
int DoublyLinkedList::removeFirst()
{ 
	if(isEmpty()){	// 1 operation
		throw EmptyDLinkedListException("Empty Doubly Linked List");
	}
	else{
		DListNode *node = header.next; // 1 operation
		node->next->prev = &header; // 1 operation
		header.next = node->next;// 1 operation
		int obj = node->obj;// 1 operation
		delete node; // 1 operation
		return obj; // 1 operation
	}
}

//-----------------------insert the new object as the last one---------------------
void DoublyLinkedList::insertLast(int newobj)
{
	DListNode *anotherNode = new DListNode(newobj, trailer.prev, &trailer);// 2 operation
	trailer.prev->next = anotherNode;// 1 operation
	trailer.prev = anotherNode;// 1 operation
}

//-----------------------remove the last object from the list------------------------
int DoublyLinkedList::removeLast()
{
	if(isEmpty()) // 1 operation
	{
		throw EmptyDLinkedListException("Empty Doubly Linked List");
	}
	else{
		DListNode *node = trailer.prev; // 1 operation
		node->prev->next = &trailer;// 1 operation
		trailer.prev = node->prev;// 1 operation
		int obj = node->obj;// 1 operation
		delete node;// 1 operation
		return obj;// 1 operation
	}
}

//-------------------------insert the new object after the node p----------------------
void DoublyLinkedList::insertAfter(DListNode &p, int newobj)
{
	DListNode *current = header.next; // 1 operation
	while(current != &p) // n operation
	{
		current = current->next; // 1 operation
	}
	
	DListNode *anotherNode = new DListNode(newobj, current, current->next); // 2 operation
	current->next->prev = anotherNode; // 1 operation
	current->next = anotherNode; // 1 operation
}

//--------------------------insert the new object before the node p--------------
void DoublyLinkedList::insertBefore(DListNode &p, int newobj)
{
	DListNode *current = header.next; // 1 operation
	while(current != &p)// n operation
	{
		current = current->next; // 1 operation
	}
	
	DListNode *anotherNode = new DListNode(newobj, current->prev, current);// 2 operation
	current->prev->next = anotherNode; // 1 operation
	current->prev = anotherNode; // 1 operation
}

//-----------------------------remove the node after the node p----------------
int DoublyLinkedList::removeAfter(DListNode &p)
{
	DListNode *current = header.next;// 1 operation
	while(current != &p) // n operation
	{
		current = current->next; // 1 operation
	}
	
	current = current->next; // 1 operation
	current->next->prev = current->prev; // 1 operation
	current->prev->next = current->next; // 1 operation
	int obj = current->obj; // 1 operation
	delete current; // 1 operation
	return obj; // 1 operation
}

//----------------------------remove the node before the node p------------
int DoublyLinkedList::removeBefore(DListNode &p)
{
	DListNode *current = header.next; // 1 operation
	while(current != &p) // n operation
	{
		current = current->next; // 1 operation
	}
	
	current = current->prev; // 1 operation
	current->next->prev = current->prev; // 1 operation
	current->prev->next = current->next; // 1 operation

	int obj = current->obj; // 1 operation
	delete current; // 1 operation
	return obj;// 1 operation
	
}

//------------------------------return the list length
int DoublyLinkedListLength(const DoublyLinkedList& dll)
{
    DListNode *current = dll.getFirst(); // 1 operation
	int count = 0;  // 1 operation
	while(current != dll.getAfterLast()) // n operation
	{
		count++; // 1 operation
		current = current->next; // 1 operation
	}

	return count; // 1 operation
}


//--------------------------------output operator
ostream& operator<<(ostream& out, const DoublyLinkedList& dll)
{
  
  
  DListNode *current = dll.getFirst(); // 1 operation
  int listsize = DoublyLinkedListLength(dll); // 1 operation
  for(int i = 0; i < listsize; i++) // n operation
  {
	  out << current->obj << " ";  // 1 operation
	  current = current->next; 	   // 1 operation
  }
  
  return out; // 1 operation
}

