/*
 name
 section
 assignment
 file
 */

#include <sstream>
#include <iostream>
#include <fstream>
#include <limits> 

#include "sort.h"


#define DEFAULT_FILENAME "rand10.csv"

std::vector<Flight> readFlights(std::string fileName);

void printFlights(std::vector<Flight> flights) {
    
    if (flights.size() < 11) {
        std::cout<<"Printing Flights..."<<std::endl;
        for (int i = 0; i < flights.size(); i++) {
            std::cout << flights.at(i).flightNum << ", " << flights.at(i).destination << ", " << flights.at(i).departureTime << ", " << flights.at(i).gateNum << std::endl;
        }
    }
    
    std::ofstream outputFile("output.txt");
    
    outputFile << "FLIGHT NUMBER,DESTINATION,DEPARTURE TIME,GATE NUMBER" << std::endl;
    for (int i = 0; i < flights.size(); i++) {
        outputFile << flights.at(i).flightNum << ", " << flights.at(i).destination << ", " << flights.at(i).departureTime << ", " << flights.at(i).gateNum << std::endl;
    }
    
    outputFile.close();
}

int main()
{
    /*
     first read flights in files using readFlights()
     descen10.csv	ascen10.csv     rand10.csv
     descen100.csv	ascen100.csv	rand100.csv
     descen1000.csv	ascen1000.csv	rand1000.csv
     descen10000.csv ascen10000.csv	rand10000.csv
     */
    
    /*
     then use each of the sorting functions on each of the generated vectors
     */
    
    /*
     then output each of the resultant sorted vectors
     format them so that they look like the table of the front of the
     instructions
     
     Flight Number	Destination Departure   Time	        Gate Number
     AA223			LAS VEGAS	21:15			A3
     BA023			DALLAS		21:00			A3
     AA220			LONDON		20:30			B4
     VI303			MEXICO		19:00			A7
     BA087			LONDON		17:45			A7
     AA342			PARIS		16:00			A7
     VI309			PRAGUE		13:20			F2
     QU607			TORONTO		08:30			F2
     AA224			SYDNEY		08:20			A7
     AF342			WASHINGTON	07:45			A3
     */
    
    /*
     then fill out the rest of the questions on the instructions
     - the number of comparisons
     
     - to test your functions experimentally use difftime explained here
     http://www.cplusplus.com/reference/ctime/time/
     */
    
    int inSortBy=0, inSortType=0;
    std::cout<<"Enter 1 to sort by departure time and 2 to sort by destination... ";
    std::cout << std::endl << "Input: ";
    std::cin >> inSortBy;
    while(!std::cin || !(inSortBy>=1 && inSortBy<=2)){
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout<<std::endl<<"Now look here- I said enter in 1 or 2."<<std::endl;
        std::cout<<"Lets try that again: ";
        std::cin>>inSortBy;
    }
    
    std::cout<<std::endl<<"Enter 1 for selection, 2 for insertion, and 3 for bubble... ";
    std::cout << std::endl << "Input: ";
    std::cin >> inSortType;
    while(!std::cin || !(inSortType>=1 && inSortType<=3)){
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout<<std::endl<<"Now look here- I said enter in 1, 2, or 3."<<std::endl;
        std::cout<<"Lets try that again: ";
        std::cin>>inSortType;
    }
    
    std::string fileName= DEFAULT_FILENAME;
    std::cout<<std::endl<<"Input the name of a (valid) .csv file containing flight data (w/ extension) ";
    std::cout<<"OR press enter to use the default test file \"" << DEFAULT_FILENAME <<"\".";
    std::cout << std::endl << "Input: ";
    
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    if (std::cin.peek() != '\n') std::cin>>fileName;
    
    std::cout<<std::endl;
    
    std::vector<Flight> flights = readFlights(fileName);
    
    std::cout<<"Sorting..."<<std::endl;
    
    if(inSortBy==1){
        if(inSortType==1)flights = selection_sort(flights, ByDepartureTime);
        else if(inSortType==2)flights = insertion_sort(flights, ByDepartureTime);
        else flights = bubble_sort(flights, ByDepartureTime);
    }else{
        if(inSortType==1)flights = selection_sort(flights, ByDestination);
        else if(inSortType==2)flights = insertion_sort(flights, ByDestination);
        else flights = bubble_sort(flights, ByDestination);
    }
    std::cout<<std::endl;
    printFlights(flights);
    
    return 0;
}

//read in the flights from the input file at fileName and store them in a vector
std::vector<Flight> readFlights(std::string fileName) {
    std::vector<Flight> flights;
    try{
        std::ifstream file(fileName);
        if(!file.good()) throw 0;
        std::string line;
        std::string element;
        
        int lineNumber = 1;     //set line number to 1 so we can skip headers
        while (getline(file, line)) {
            if (lineNumber != 1) {
                Flight newFlight = Flight();
                std::stringstream lineStream(line);
                
                int elementNumber = 1;
                while(getline(lineStream, element, ',')) {          //read from line for individual elements
                    switch (elementNumber) {
                        case 1:
                            newFlight.flightNum = element;
                            break;
                            
                        case 2:
                            newFlight.destination = element;
                            break;
                            
                        case 3:
                            newFlight.departureTime = element;
                            break;
                            
                        case 4:
                            newFlight.gateNum = element;
                            break;
                            
                        default:
                            break;
                    }
                    elementNumber += 1;
                }
                flights.push_back(newFlight);
            }
            lineNumber += 1;
        }
    }catch(...){
        std::cout<<"Error reading file \""<<fileName<<"\". please ensure it is valid."<<std::endl;
        exit(1);
    }
    return flights;
}

