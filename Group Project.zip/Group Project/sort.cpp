/*
Edited by: Louis Julian, 
CSCE 221 503
Programing Assignment 2
sort.cpp
*/

#include <iostream>

#include "sort.h"

//Note: comparisons are first element >= second element and sortOpt is destination if true otherwise departure time

//TO DO: use this to keep track of comparisons
long num_cmps=0;

std::vector<Flight> selection_sort(std::vector<Flight> flights,
				   SortOption sortOpt)
{
	if(flights.size()>1){
		bool (*compFunc)(Flight, Flight) = &(sortOpt ? compareToDepartureTime : compareToDestination);
//If you don't know what the above line is...
//"compFunc" is a pointer to a function and "(boolean)?(if true):(if false)" is called a ternary operation.
		std::vector<Flight>::iterator it1 = flights.begin();
		do{//iterate list sans last element
			std::vector<Flight>::iterator it2 = it1, lowest=it2+1;
			do{//iterate list starting after it1 including last element
                ++num_cmps;
				if((*compFunc)(*lowest,*it2)){lowest=it2;}//save the lowest element
				++it2;
			}while(it2 != flights.end());
			std::iter_swap(it1,lowest);//swap the lowest element from the list beyond it1 with whats in its place
		}while(++it1 != flights.end()-1);
	}
	
	std::cout<<"Comparisons: "<<num_cmps<<std::endl;
	
  return flights; 
}

std::vector<Flight> insertion_sort(std::vector<Flight> flights,
				   SortOption sortOpt)
{
	if(flights.size()>1){
		bool (*compFunc)(Flight, Flight) = &(sortOpt ? compareToDepartureTime : compareToDestination);
		std::vector<Flight>::iterator it1 = flights.begin()+1;
		do{//iterate through all elements
			std::vector<Flight>::iterator it2 = it1;
			while(it2!=flights.begin()){//iterate backwards as long as previous elements are bigger
++num_cmps;//If num_cmp is in the while loop, as suggested by the instructions, it will provide an incorrect value ONLY for ascen10000, but its okay like this. We have no idea why.
				if((*compFunc)(*it2,*(it2-1))) break;
				std::iter_swap(it2,it2-1);//swap larger sorted element with smaller unsorted element
				--it2;
			}
		}while(++it1 != flights.end());
	}
	
	std::cout<<"Comparisons: "<<num_cmps<<std::endl;

  return flights;
}

std::vector<Flight> bubble_sort(std::vector<Flight> flights,
				SortOption sortOpt)
{
	if(flights.size()>1){
		bool (*compFunc)(Flight, Flight) = &(sortOpt ? compareToDepartureTime : compareToDestination);
		
		for(int n=1; n<flights.size(); ++n){//loop n the number of elements minus 1
			std::vector<Flight>::iterator it = flights.begin();
			do{//iterate elements up to end minus n minus 1
++num_cmps;
				if((*compFunc)(*it,*(it+1))){std::iter_swap(it,(it+1));}//swap current element with the one after it if greater
			}while(++it != flights.end()-n);
		}
	}
	
	std::cout<<"Comparisons: "<<num_cmps<<std::endl;
	
  return flights;
}
