#include <iostream>
#include <queue>
#include <vector>
#include <fstream>
#include <sstream>
#include <math.h>
#include <string>
using namespace std;

enum color { red, black };

template <typename T>
struct Node
{
	T value;
	Node<T>* left;
	Node<T>* right;
	Node<T>* parent;
	int search_time;
	color node_color; 
	Node(T val = T(), Node<T>* l = NULL, Node<T>* r = NULL, Node<T>* p = NULL, color col = color::red)
		: value(val), left(l), right(r), parent(p), search_time(0), node_color(col) {}
	Node(const Node<T>* other)
	{
		value = other.value;
		node_color = other.node_color;
		search_time = other.search_time;
	}
	Node<T>* insertRight(T obj);
	Node<T>* insertLeft(T obj);
	bool is_leaf() { return (left == 0 && right == 0); } 
};

template <class T>
Node<T>* Node<T>::insertRight(T obj) {
	this->right = new Node<T>(obj);
	this->right->parent = this;
	return this->right;
}

template <class T>
Node<T>* Node<T>::insertLeft(T obj) {
	this->left = new Node<T>(obj);
	this->left->parent = this;
	return this->left;
}

template <typename T>
struct BTree
{
protected:
	int size;

public:
	Node<T>* root;
	int depth;
	BTree() : root(NULL), size(0), depth(1) {}
	BTree(const BTree<T>& other);
	BTree<T>& operator=(const BTree<T>& other);
	//BTree<T>& operator=(const BTree<T> other);
	Node<T>* get_root() { return root; }
	const Node<T>* get_root() const { return root; }
	virtual Node<T>* insert(T obj);
	Node<T>* search(T obj);
	void update_search_times();
	float get_average_search_time();
	ostream& inorder(ostream& out);
	int sizeCalc();
	int search_time_single_update(T obj);
	ostream& print_level_by_level(ostream& out);
private:
	void copy_helper(Node<T>* copy_to, const Node<T>* copy_from) const;
	virtual Node<T>* insert_helper(T obj, Node<T>* node);
	Node<T>* search_helper(T obj, Node<T>* node);
	ostream& inorder_helper(ostream& out, Node<T>* node);
	void update_search_times_helper(Node<T>* node, int depth);
	T get_total_search_time(Node<T>* node);
	virtual void pretty_print_node(ostream& out, Node<T>* node);
	void print_level_helper(Node<T>* node, std::vector<std::queue<Node<T>*>> &vec, int depth);
	int search_time_single_helper(Node<T>* node, T obj, int depth);
	int search_time_counter(int count, Node<T>* node);
};

template <typename T>
ostream& operator<<(ostream& out, BTree<T>& tree)
{
	return out;
}

template <typename T>
ostream& operator<<(ostream& out, Node<T> node)
{
	return out << "( " << node.value << ", " << node.search_time << ", " << node.node_color << " )";
}

template <typename T>
void BTree<T>::pretty_print_node(ostream& out, Node<T>* node)
{
	out << node->value << "[" << node->search_time << "] ";
}

template <typename T>
istream& operator>>(istream& in, BTree<T>& tree)
{
	T num;
	while (in >> num) {
		tree.insert(num);
	}
	
}

template <typename T>
BTree<T>::BTree(const BTree<T>& other)
{
	size = other.size;
	depth = other.depth;
	root = new Node<T>;
	copy_helper(root, other.get_root());
	
}

template <typename T>
BTree<T>& BTree<T>::operator=(const BTree<T>& other)
{
	size = other.size;
	depth = other.depth;
	root = new Node<T>;
	copy_helper(root, other.get_root());
	
}

//template <typename T>
//BTree<T>& BTree<T>::operator=(const BTree<T> other)
//{
/*
*/
//}

template <typename T>
void BTree<T>::copy_helper(Node<T>* copy_to, const Node<T>* copy_from) const
{
}



template <typename T>
Node<T>* BTree<T>::insert(T obj)
{
	size += 1;
	if (this->get_root() == NULL) { 
		root = new Node<T>(obj);
		root->search_time = 1;
		return root;
	}
	Node<T>* out = insert_helper(obj, get_root());
	out->search_time = search_time_single_update(obj);
	if (out->search_time > depth) {
		depth = out->search_time;
	}
	return out;
}

template <class T>
Node<T>* BTree<T>::insert_helper(T obj, Node<T>* m) {
	if (obj > m->value) {
		if (m->right == nullptr) {
			return m->insertRight(obj);
		}
		else { 
			return insert_helper(obj, m->right);
		}
	}
	else {
		if (m->left == nullptr) {
			return m->insertLeft(obj);
		}
		else {
			return insert_helper(obj, m->left);
		}
	}
}

template <typename T>
Node<T>* BTree<T>::search(T obj)
{
	Node<T>* temp = search_helper(obj, this->get_root());
	if (temp == nullptr) {
		throw("Nothing found...");
	}
	return temp;
}

template <typename T>
Node<T>* BTree<T>::search_helper(T obj, Node<T>* node)
{
	if (node == NULL) {
		return -1;
	}
	else if (node->value == obj) {
		return node;
	}
	else if (obj>node->value) {
		return search_helper(obj, node->right);
	}
	else if (obj<node->value) {
		return search_helper(obj, node->left);
	}
	else {

	}
}

template <class T>
int BTree<T>::search_time_single_update(T obj) {
	return search_time_single_helper(this->get_root(), obj, 1);
}

template <class T>
int BTree<T>::search_time_single_helper(Node<T>* node, T obj, int depth) {
	if (node == NULL) {
		return -99;
	}
	else if (node->value == obj) {
		return depth;
	}
	else if (node->value < obj) {
		return search_time_single_helper(node->right, obj, depth + 1);
	}
	else if (node->value > obj) {
		return search_time_single_helper(node->left, obj, depth + 1);
	}
	else {

	}
}

template <typename T>
void BTree<T>::update_search_times_helper(Node<T>* node, int depth)
{
	if (node != nullptr) {
		node->search_time = depth;
		update_search_times_helper(node->left, depth + 1);
		update_search_times_helper(node->right, depth + 1);
	}
}

template <typename T>
void BTree<T>::update_search_times()
{
	update_search_times_helper(get_root(), 1);
}

template <typename T>
ostream& BTree<T>::inorder_helper(ostream& out, Node<T>* node)
{
	if (node != nullptr) {
		inorder_helper(out, node->left);
		pretty_print_node(out, node);
		inorder_helper(out, node->right);
		return out;
	}
}

template <typename T>
ostream& BTree<T>::inorder(ostream& out)
{
	out << "Value         Search Cost" << endl << endl;
	if (size < 16) {
		inorder_helper(out, get_root());
	}
	else {
		ofstream excessNodes("excess.txt");
		inorder_helper(excessNodes, get_root());
	}
	
	return out;
}

template <typename T>
ostream& BTree<T>::print_level_by_level(ostream& out)
{
	if (this->depth > 9) {
		std::cout << this->depth;
		out << "Too many layers..." << std::endl;
		return out;
	}
	std::vector<std::queue<Node<T>*>> tVec;
	for (int i = 0; i < depth; i++) { 
		std::queue<Node<T>*> moving;
		tVec.push_back(moving);
	}
	print_level_helper(this->get_root(), tVec, 0);
	for (int i = 0; i < tVec.size(); i++) {
		while (!tVec.at(i).empty()) {
			out << " ";
			Node<T>* temp = tVec.at(i).front();
			tVec.at(i).pop();
			if (temp == nullptr) {
				out << "X";
			}
			else {
				out << temp->value;
			}
		}
		out << " [" << i + 1 << "]" << std::endl;
	}
	
	return out;
}

template <class T>
void BTree<T>::print_level_helper(Node<T>* node, std::vector<std::queue<Node<T>*>> &vec, int depth) {
	if (node != nullptr) { 
		vec.at(depth).push(node); 
		if (node->left == nullptr) {
			for (int i = node->search_time; i < this->depth; i++) { 
				for (int j = 0; j < pow(2, i - node->search_time); j++) {
					vec.at(i).push(NULL); 
				}
			}
		}
		else {
			print_level_helper(node->left, vec, depth + 1); 
		}

		if (node->right == nullptr) { 
			for (int i = node->search_time; i < this->depth; i++) {
				for (int j = 0; j < pow(2, i - node->search_time); j++) {
					vec.at(i).push(NULL);
				}
			}
		}
		else {
			print_level_helper(node->right, vec, depth + 1);
		}
		
	}
}

template <typename T>
T BTree<T>::get_total_search_time(Node<T>* node)
{
	return search_time_counter(0, root);
}

template <class T>
int BTree<T>::search_time_counter(int count, Node<T>* node) {
	if (node->left != nullptr) {
		count = search_time_counter(count, node->left);
	}
	if (node->right != nullptr) {
		count = search_time_counter(count, node->right);
	}
	return count += node->search_time;
}

template <typename T>
float BTree<T>::get_average_search_time()
{
	float total = get_total_search_time(this->get_root());
	return total / static_cast<float>(size);
}
template<typename T>
int BTree<T>::sizeCalc() {
	return this->size;
}
