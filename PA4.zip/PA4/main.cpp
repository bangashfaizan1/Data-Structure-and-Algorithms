#include "BTree.h"
#include <iostream>
#include <fstream>

template<typename T>
BTree<T> read_file(string file_name);

using namespace std;

int main()
{
	
	string input;
	cout << "Please enter file name: " << endl;
	cin >> input;
	cout << endl;
	ifstream file;
	ofstream outFS;
	file.open(input);
	int myd;
	int totalNodes = 0;
	vector<int> inputData;
	if (file.is_open()) {
		cout << "Input: " << endl;
		while (file >> myd) {
			inputData.push_back(myd);
			totalNodes++;
			cout << myd << endl;
		}
	}
	else {
		cout << "Could not open file..." << endl;
	}
	BTree<int> myTree;
	for (int i = 0; i < inputData.size(); i++) {
		myTree.insert(inputData[i]);
	}
	cout << endl;
	cout << "Total number of nodes is " << myTree.sizeCalc() << endl << endl;
	cout << "Inorder Traversal: ";
	myTree.inorder(cout) << endl << endl;
	cout << "Average search time: ";
	cout << myTree.get_average_search_time() << endl << endl;
	myTree.print_level_by_level(cout);
	
}

template<typename T>
BTree<T> read_file(string file_name)
{
	BTree<T> myTree1;
	return myTree1;
}
