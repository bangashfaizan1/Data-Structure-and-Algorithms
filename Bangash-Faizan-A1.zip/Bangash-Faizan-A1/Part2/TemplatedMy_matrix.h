/* My_matrix.h

Header file for the class My_matrix

Write your name and UIN here

*/

#include <iostream>
#include <stdexcept>
#include <exception>
#include <string>
#include <sstream>

using namespace std;
// Definitions of user defined type exceptions 
struct invalid_input : public exception {
  virtual const char* what() const throw()
  { return "Invalid matrix input"; }
};

struct incompatible_matrices : public exception {
  virtual const char* what() const throw()
  { return "Incompatible matrices"; }
};

template <typename T>
class TemplatedMy_matrix {

  //member variables
  int n, m;
  T **ptr;
  //void allocate_memory();  // optional
  
public:	
  //member functions
  TemplatedMy_matrix();  // default constructor
  TemplatedMy_matrix(int n1, int m1); // parameter constructor
  ~TemplatedMy_matrix(); // destructor
  TemplatedMy_matrix(const TemplatedMy_matrix& mat); // copy constructor
 // My_matrix(My_matrix&& mat);  // move constructor (optional)
  TemplatedMy_matrix& operator=(const TemplatedMy_matrix& mat); //copy assignment operator
  //My_matrix& operator=(My_matrix&& mat); // move assignment operator (optional)
  T number_of_rows() const; 
  T number_of_columns() const;
  T* operator()(int i) const; // overloaded to access to ith row
  T& operator()(int i, int j); // overloaded to access (i,j) element
  T operator()(int i, int j) const; // overloaded to access (i,j) element
  T elem(int i, int j) const; // overloaded to access (i,j) element
  T& elem(int i, int j); // overloaded to access (i,j) element
  //---------My Defined Function------------------
  void init(T **ptr, int n, int m); // function to give access to the input
};

// see the handout for the description of these operators
template <typename T>
ostream& operator<<(ostream& out, const TemplatedMy_matrix<T>& mat);
template <typename T>
istream& operator>>(istream& in, TemplatedMy_matrix<T>& mat);
template <typename T>
TemplatedMy_matrix<T> operator+(const TemplatedMy_matrix<T>& mat1, const TemplatedMy_matrix<T>& mat2);
template <typename T>
TemplatedMy_matrix<T> operator*(const TemplatedMy_matrix<T>& mat1, const TemplatedMy_matrix<T>& mat2);

/*----------------------------------------------------------------------


                            Implementation 

-------------------------------------------------------------------------*/

/* 
Implementation of the clas My_matrix
*/

//------------------default constructor------------------
template <typename T>
TemplatedMy_matrix<T>::TemplatedMy_matrix()
{
  // add your code here
  int n = 0;
  int m = 0;
  ptr = nullptr;

}

/*void My_matrix::allocate_memory()
{
  // add your code here
}
*/

//------------------parameter constructor-----------------
template <typename T>
TemplatedMy_matrix<T>::TemplatedMy_matrix(int n1, int m1)
{
  // add your code here
  n = n1;
  m = m1;
  ptr= new T*[n];

  for(int i=0;i<n;i++)
    ptr[i]=new T[m];  
  
}

//---------------------Destructor---------------------------
template <typename T>
TemplatedMy_matrix<T>::~TemplatedMy_matrix()
{
  // add your code here
  for(int i=0; i<n; i++)
    delete ptr[i];

  delete ptr;
  
}

//------------------Copy Constructor ----------------------
template <typename T>
TemplatedMy_matrix<T>::TemplatedMy_matrix(const TemplatedMy_matrix& mat)
{
  // add your code here
  n = mat.n;
  m = mat.m;

  ptr = new T*[n];
  
  for(int i=0;i<n;i++)
    ptr[i]=new T[m];

  for(int i=0;i<n;i++)
    for(int j=0;j<m;j++)
      ptr[i][j]=mat.ptr[i][j];

}

/*
// move constructor (optional)
}

My_matrix::My_matrix(My_matrix&& mat)
{
  // add your code here
*/

//----------------------Copy Assignment Operator ------------------
template <typename T>
TemplatedMy_matrix<T>& TemplatedMy_matrix<T>::operator=(const TemplatedMy_matrix& mat)
{
  // add your code here
  n = mat.number_of_rows();
  m = mat.number_of_columns();
  ptr = new T*[n];
  
  for(int i=0;i<n;i++)
    ptr[i]= new T[m];
  
  
  for(int i=0;i<n;i++)
    for(int j=0;j<m;j++)
      ptr[i][j]=mat.elem(i,j);

return *this;

}

/*
// move assignment operator (optional)
My_matrix& My_matrix::operator=(My_matrix&& mat)
{
  // add your code here
}
*/

//-----------------------Return number of rows-------------------------
template <typename T>
T TemplatedMy_matrix<T>::number_of_rows() const
{
  // add your code here
  return n;
}

//-----------------------Return number of columns-------------------------
template <typename T>
T TemplatedMy_matrix<T>::number_of_columns() const
{
  // add your code here
  return m;
}

//-----------------------overloaded to access to ith row-------------------
template <typename T>
T* TemplatedMy_matrix<T>::operator()(int i) const
{
  // add your code here
  return ptr[i];

}

//-----------------------overloaded to access (i,j) element----------------
template <typename T>
T TemplatedMy_matrix<T>::operator()(int i, int j) const
{
  // add your code here
  return ptr[i][j];
}

//------------------------overloaded to access (i,j) element----------------
template <typename T>
T& TemplatedMy_matrix<T>::operator()(int i, int j)
{
  // add your code here
  return ptr[i][j];
}

//------------------------overloaded to access (i,j) element----------------
template <typename T>
T TemplatedMy_matrix<T>::elem(int i, int j) const
{
  
  if (i < 0 || i >= n) throw out_of_range("Out of range");
  if (j < 0 || j >= m) throw out_of_range("Out of range");
  // add your code here
  return ptr[i][j];
  
}

//-------------------------overloaded to access (i,j) element-----------------
template <typename T>
T& TemplatedMy_matrix<T>::elem(int i, int j)
{
  
  // add your code here
  return ptr[i][j];
}

//--------------------------Function to give access ---------------------------
template <typename T>
void TemplatedMy_matrix<T>::init(T **p, int r, int c){
  ptr = p;
  n = r;
  m = c;
}

//-----------------------Overload the extraction operator-----------------------
template <typename T>
ostream& operator<<(ostream& out, const TemplatedMy_matrix<T>& mat)
{
  // add your code here
  
  for (int i = 0; i< mat.number_of_rows(); i++){
    for (int j = 0; j < mat.number_of_columns(); j++){
      out << mat.elem(i,j) << " ";
    }  
    out << endl;
  }

return out;

}

//------------------------Input operator ------------------------------------
template <typename T>
istream& operator>>(istream& in, TemplatedMy_matrix<T>& mat)
{
  // add your code here
  int n, m;
  int temp_c=0;
  T temp;
  int first_line= 0;
  
  string s;
 
  try
  {
    while (getline(in,s))
    {

      if (first_line==0)
      {
          istringstream iss(s);
          iss>>n;
          iss>>m;
          first_line++;
          T** ptr = new T*[n];
          
          for(int i=0;i<n;i++)
            ptr[i]=new T[m];

          for(int i=0;i<n;i++)
            for(int j=0;j<m;j++)
              ptr[i][j]=0;
    
          mat.init(ptr,n,m);
      
      }
      else
      {
          istringstream iss(s);     
        
       //{ for (int i = 0; i < n; i++)
          for (int j = 0; j < m; j++)
           {       
              iss >> temp;       
              mat.elem(first_line-1,j)= temp;
              if(iss.eof()) throw out_of_range ("Incorect Input");
        
              temp_c++;
            }  

            first_line++;
            if (temp_c > m) throw out_of_range("Error incorrect input");
            temp_c=0;            
      }
           

    }
    
  } 
  catch(exception &error)
  {

   cerr << "Error: " << error.what() << endl;
  }      
    

}


//----------------------------------Addition ---------------------------------------
template <typename T>
TemplatedMy_matrix<T> operator+(const TemplatedMy_matrix<T>& mat1, const TemplatedMy_matrix<T>& mat2)
{
  // add your code 
  try
  {
    if (mat1.number_of_rows() != mat2.number_of_rows() && mat1.number_of_columns() != mat2.number_of_columns()) throw out_of_range("Incorrect Input for addition ");
      TemplatedMy_matrix <T> result(mat1.number_of_rows(), mat1.number_of_columns());

        for (int i = 0; i < mat1.number_of_rows(); i++)  {

          for (int j = 0; j < mat2.number_of_columns(); j++) {

             result.elem(i,j) = mat1.elem(i,j) + mat2.elem(i,j);

        }

      }
    return result;
   }
   catch(exception &error){
    cerr << "Error: " << error.what() << endl;
  }   
  
}


//--------------------------------Multiplication -----------------------------------
template  <typename T>
TemplatedMy_matrix<T> operator*(const TemplatedMy_matrix<T>& mat1, const TemplatedMy_matrix<T>& mat2)
{
  // add your code here
  //My_matrix result(mat1.number_of_rows(), mat2.number_of_columns()); 
  
  try
  {
    if(mat1.number_of_columns() != mat2.number_of_rows() ) throw out_of_range ("Incorrect input");
    TemplatedMy_matrix<T> result(mat1.number_of_rows(), mat2.number_of_columns()); 

      for(int i=0;i<mat1.number_of_rows();i++) 
      { 
        for(int j=0;j<mat2.number_of_columns();j++) 
        { 
            result.elem(i,j)=0; 
            for(int k=0;k<mat1.number_of_columns();k++){ 
                result.elem(i,j)+=mat1.elem(i,k) * mat2.elem(k,j); 
            } 
        }       
      } 
  
  return result; 
  } 
  catch(exception &error){
    cerr << "Error: " << error.what() << endl;
  }
   
}




