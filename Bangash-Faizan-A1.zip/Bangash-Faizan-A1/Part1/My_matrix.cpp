/* 
Implementation of the clas My_matrix
*/

#include "My_matrix.h"
#include <stdexcept>
#include <string>
#include <sstream>

//------------------default constructor------------------
My_matrix::My_matrix()
{
  // add your code here
  int n = 0;
  int m = 0;
  ptr = nullptr;

}

/*void My_matrix::allocate_memory()
{
  // add your code here
}
*/

//------------------parameter constructor-----------------
My_matrix::My_matrix(int n1, int m1)
{
  // add your code here
  n = n1;
  m = m1;
  ptr= new int*[n];

  for(int i=0;i<n;i++)
    ptr[i]=new int[m];  
  
}

//---------------------Destructor---------------------------
My_matrix::~My_matrix()
{
  // add your code here
  for(int i=0; i<n; i++)
    delete ptr[i];

  delete ptr;
  
}

//------------------Copy Constructor ----------------------
My_matrix::My_matrix(const My_matrix& mat)
{
  // add your code here
  n = mat.n;
  m = mat.m;

  ptr = new int*[n];
  
  for(int i=0;i<n;i++)
    ptr[i]=new int[m];

  for(int i=0;i<n;i++)
    for(int j=0;j<m;j++)
      ptr[i][j]=mat.ptr[i][j];

}

/*
// move constructor (optional)
}

My_matrix::My_matrix(My_matrix&& mat)
{
  // add your code here
*/

//----------------------Copy Assignment Operator ------------------
My_matrix& My_matrix::operator=(const My_matrix& mat)
{
  // add your code here
  n = mat.number_of_rows();
  m = mat.number_of_columns();
  ptr = new int*[n];
  
  for(int i=0;i<n;i++)
    ptr[i]=new int[m];
  
  
  for(int i=0;i<n;i++)
    for(int j=0;j<m;j++)
      ptr[i][j]=mat.elem(i,j);

return *this;

}

/*
// move assignment operator (optional)
My_matrix& My_matrix::operator=(My_matrix&& mat)
{
  // add your code here
}
*/

//-----------------------Return number of rows-------------------------
int My_matrix::number_of_rows() const
{
  // add your code here
  return n;
}

//-----------------------Return number of columns-------------------------
int My_matrix::number_of_columns() const
{
  // add your code here
  return m;
}

//-----------------------overloaded to access to ith row-------------------
int* My_matrix::operator()(int i) const
{
  // add your code here
  return ptr[i];

}

//-----------------------overloaded to access (i,j) element----------------
int My_matrix::operator()(int i, int j) const
{
  // add your code here
  return ptr[i][j];
}

//------------------------overloaded to access (i,j) element----------------
int& My_matrix::operator()(int i, int j)
{
  // add your code here
  return ptr[i][j];
}

//------------------------overloaded to access (i,j) element----------------
int My_matrix::elem(int i, int j) const
{
  
  if (i < 0 || i >= n) throw out_of_range("Out of range");
  if (j < 0 || j >= m) throw out_of_range("Out of range");
  // add your code here
  return ptr[i][j];
  
}

//-------------------------overloaded to access (i,j) element-----------------
int& My_matrix::elem(int i, int j)
{
  
  // add your code here
  return ptr[i][j];
}

//--------------------------Function to give access ---------------------------
void My_matrix::init(int **p, int r, int c){
  ptr = p;
  n = r;
  m = c;
}

//-----------------------Overload the extraction operator-----------------------
ostream& operator<<(ostream& out, const My_matrix& mat)
{
  // add your code here
  
  for (int i = 0; i< mat.number_of_rows(); i++){
    for (int j = 0; j < mat.number_of_columns(); j++){
      out << mat.elem(i,j) << " ";
    }  
    out << endl;
  }

return out;

}

//------------------------Input operator ------------------------------------
istream& operator>>(istream& in, My_matrix& mat)
{
  // add your code here
  int n, m, temp_c=0;
  int temp;
  int first_line= 0;
  
  string s;
 
  try
  {
    while (getline(in,s))
    {

      if (first_line==0)
      {
          istringstream iss(s);
          iss>>n;
          iss>>m;
          first_line++;
          int** ptr = new int*[n];
          
          for(int i=0;i<n;i++)
            ptr[i]=new int[m];

          for(int i=0;i<n;i++)
            for(int j=0;j<m;j++)
              ptr[i][j]=0;
    
          mat.init(ptr,n,m);
      
      }
      else
      {
          istringstream iss(s);     
        
       //{ for (int i = 0; i < n; i++)
          for (int j = 0; j < m; j++)
           {       
              iss >> temp;       
              mat.elem(first_line-1,j)= temp;
              if(iss.eof()) throw out_of_range ("Incorect Input");
        
              temp_c++;
            }  

            first_line++;
            if (temp_c > m) throw out_of_range("Error incorrect input");
            temp_c=0;            
      }
           

    }
    
  } 
  catch(exception &error)
  {

   cerr << "Error: " << error.what() << endl;
  }      

}


//----------------------------------Addition ---------------------------------------
My_matrix operator+(const My_matrix& mat1, const My_matrix& mat2)
{
  // add your code 
  try
  {
    if (mat1.number_of_rows() != mat2.number_of_rows() && mat1.number_of_columns() != mat2.number_of_columns()) throw out_of_range("Incorrect Input for addition ");
      My_matrix result(mat1.number_of_rows(), mat1.number_of_columns());

        for (int i = 0; i < mat1.number_of_rows(); i++)  {

          for (int j = 0; j < mat2.number_of_columns(); j++) {

             result.elem(i,j) = mat1.elem(i,j) + mat2.elem(i,j);

        }

      }
    return result;
   }
   catch(exception &error){
    cerr << "Error: " << error.what() << endl;
  }   
  
}


//--------------------------------Multiplication -----------------------------------
My_matrix operator*(const My_matrix& mat1, const My_matrix& mat2)
{
  // add your code here
  
  
  try
  {
    if(mat1.number_of_columns() != mat2.number_of_rows() ) throw out_of_range("Incorrect input");
    My_matrix result(mat1.number_of_rows(), mat2.number_of_columns()); 

      for(int i=0;i<mat1.number_of_rows();i++) 
      { 
        for(int j=0;j<mat2.number_of_columns();j++) 
        { 
            result.elem(i,j)=0; 
            for(int k=0;k<mat1.number_of_columns();k++){ 
                result.elem(i,j)+=mat1.elem(i,k) * mat2.elem(k,j); 
            } 
        }       
      } 
  
  return result; 
  } 
  catch(exception &error){
    cerr << "Error: " << error.what() << endl;
  }
   
}


