// main.cpp
// Tests all functionality of the class My_matrix class.

#include <iostream>
#include <fstream>
#include "My_matrix.h"

int main(){
  
  // Some test cases are expected to throw an exception.
  // Add more try and catch blocks as necessary for your code
  // to finish execution.
    
  try{
    
    // Test 1
    // * Create an object of type My_matrix, called m1, using constructor
    // * Initialize m1 in main (by assigning numbers to matrix elements)
    // * Display m1 on the screen using the operator <<
    My_matrix m1(2,3);
    m1.elem(0,0) = 1;
    m1.elem(0,1) = 2;
    m1.elem(0,2) = 7;
    m1.elem(1,0) = 4;
    m1.elem(1,1) = 5;
    m1.elem(1,2) = 0;

    cout << "M1" << endl;
    cout << m1;   
    cout << endl;
    
    // Test 2
    // * Create an object of type My_matrix, called m2, using (default)
    //   constructor
    // * Open an input file containing a matrix (row by row)
    // * Initialize m2 by reading from the input file using
    //   the operator >>
    // * Open an output file (can be empty)
    // * Write m2 to the output file using the operator <<

    My_matrix m2(2,3);
    ifstream i;
    i.open("input.txt");  

        i >> m2;

    i.close();

    cout << "M2" << endl;
    cout << m2 << endl;

    ofstream myfile ("example.txt");
    if (myfile.is_open())
    {
        myfile << m2;
        myfile.close();
    } 
    
    // Test 3
    // * Use the copy constructor to make a copy of m1 called m3
    // * Apply the copy assignment to m1 called m4
    // * Display m3 and m4 on the screen using the operator <<

    My_matrix m3(m1);
    My_matrix m4;
    m4 = m1;
    cout << "M3- copy constructor" << endl;
    cout << m3 << endl;
    cout << "M4- copy assignment" << endl;
    cout << m4 << endl;

    // Test 4
    // * Test the matrix multiplication operator (operator*)
    // * Apply the multiplication operator to valid and invalid cases
    // * Display the resulting matrix and its number of rows and columns
    My_matrix m5(3,2);
    m5.elem(0,0) = 1;
    m5.elem(0,1) = -1;
    m5.elem(1,0) = 2;
    m5.elem(1,1) = -2;
    m5.elem(2,0) = 3;
    m5.elem(2,1) = -3;

     cout << "M5" << endl;
     cout <<  m5 << endl;

     cout << m1 << endl;

     cout << "M1 * M5" << endl;
     cout <<  m1*m5  << endl;

     cout << "M1 * M2" << endl;
     cout << endl;
     cout << m2;
     cout << m1*m2;
    
    // Test 5
    // * Test the matrix addition operator (operator+)
    // * Apply the multiplication operator to valid and invalid cases
    // * Display the resulting matrix and its number of rows and columns
    cout << "M1 + M2" << endl; 
    cout << m1 + m2 << endl;

  } catch(exception &error){
    cerr << "Error: " << error.what() << endl;
  }
}
