#include "text_freq.h"
#include "my_map.h"
#include "key_value.h"
#include <fstream>
#include <sstream>
using namespace std;

string read_file(string file_name)
{
    //FINISH THIS FUNCTION
    //this should read the file, and return the string of the whole file
    ifstream file;
    file.open(file_name);
    
    string inputData = "";
    string myd = "";
    if (file.is_open()) {
        while (file >> myd) {
           inputData += myd + " ";
        }
    }
    else {
        cout << "Could not open file..." << endl;
    }
    return inputData;
}

string remove_punctuation(string& text)
{
    string result;
    std::remove_copy_if(text.begin(), text.end(),            
                        std::back_inserter(result), //Store output           
                        std::ptr_fun<int, int>(&std::ispunct));
    return result;
}

my_map<string, double> create_freq_map(const string& text)
{
    my_map<string,double> freq_map;
    stringstream ss(read_file(text));
    string myd;
    int count = 0;
    while (ss >> myd) {
        freq_map[remove_punctuation(myd)] += 1;
    }

    for (auto word : freq_map){
        count = count + word.value;

    }
    cout << count << endl;

    for (auto word : freq_map)
        freq_map[word.key] /= count;

    //FINISH THIS FUNCTION
    //this should find the frequecies of every word in the text


    return freq_map;
}

vector<key_value<string,double>> vectorize_map(my_map<string, double>& freq_map)
{
    vector<key_value<string,double>> freq_vec;

    //FINISH THIS FUNCTION
    //this should return a sorted vector of the results
    for (auto word : freq_map)
        freq_vec.push_back(key_value<string,double>(word.key,freq_map[word.key]));
    
    sort(freq_vec.begin(),freq_vec.end());


    return freq_vec;
}

void remove_stop_words(vector<key_value<string, double>>& freq_vec, vector<string> stop_words)
{
    //FINISH THIS FUNCTION
    //this function should remove the elements contained in stop_words from freq_vec 
    for (auto i = freq_vec.begin(); i != freq_vec.end(); i++)
    {
        for (int j = 0; j != stop_words.size()-1; j++)
        {
            if (i->key == stop_words[j]) {
                freq_vec.erase(i);
                i--;

            }
        }

    }

}

void print_top_20_freqs(const vector<key_value<string,double>>& freq_vec, ostream& out)
{
    //prints the top 20 frequencies to out
   for(int i = freq_vec.size()-1; i > freq_vec.size()-21; i--){
        //if(i==20)
            //break;
        out << freq_vec[i] << endl;
    }
    


}
